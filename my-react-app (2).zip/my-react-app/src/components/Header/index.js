import { useState } from "react";
import styles from "./Header.module.css";

function Header({ onSearch }) {
  const [query, setQuery] = useState("");

  const handleSearch = () => {
    if (onSearch) onSearch(query); // envia o texto para o componente pai
  };

  return (
    <div
  className={styles.banner}
  style={{ backgroundImage: "url('/banner.png')" }}
>
  <div className={styles.overlay}>
    <span className={styles.title}>Família Real Britânica</span>

    <div className={styles.searchContainer}>
      <input
        type="text"
        placeholder="Buscar integrantes..."
        className={styles.searchInput}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <button className={styles.searchButton} onClick={handleSearch}>
        Buscar
      </button>

      <button
        className={styles.clearButton}
        onClick={() => {
          setQuery("");
          if (onSearch) onSearch("");
        }}
      >
        Limpar
      </button>
    </div>
  </div>
</div>

  );
}

export default Header;
