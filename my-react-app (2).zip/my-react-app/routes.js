import { Link } from "react-router-dom";

function Header() {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/integrantes">Integrantes</Link>
    </nav>
  );
}
